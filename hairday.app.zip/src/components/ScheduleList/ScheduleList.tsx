import { AppointmentItem } from "../AppointmentItem/AppointmentItem"
import type { Appointment } from "../../types/Appointment"
import { getPeriod } from "../../utils/getPeriod"

type Props = {
  appointments: Appointment[]
}

export function ScheduleList({ appointments }: Props) {

  const sortedAppointments = [...appointments].sort((a, b) =>
    a.time.localeCompare(b.time)
  )

  const morningAppointments = sortedAppointments.filter(
    (appointment) => getPeriod(appointment.time) === "morning"
  )

  const afternoonAppointments = sortedAppointments.filter(
    (appointment) => getPeriod(appointment.time) === "afternoon"
  )

  const nightAppointments = sortedAppointments.filter(
    (appointment) => getPeriod(appointment.time) === "night"
  )

  return (
    <div className="flex flex-col gap-6">

      <div>
        <h2>Manhã</h2>
        {morningAppointments.map((appointment) => (
          <AppointmentItem
            key={appointment.id}
            appointment={appointment}
          />
        ))}
      </div>

      <div>
        <h2>Tarde</h2>
        {afternoonAppointments.map((appointment) => (
          <AppointmentItem
            key={appointment.id}
            appointment={appointment}
          />
        ))}
      </div>

      <div>
        <h2>Noite</h2>
        {nightAppointments.map((appointment) => (
          <AppointmentItem
            key={appointment.id}
            appointment={appointment}
          />
        ))}
      </div>

    </div>
  )
}