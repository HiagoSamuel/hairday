import type { Appointment } from "../../types/Appointment"

type Props = {
  appointment: Appointment
}

export function AppointmentItem({ appointment }: Props) {

  const formattedDate = new Date(appointment.date).toLocaleDateString("pt-BR")

  return (
    <div>
      <p>{appointment.name}</p>
      <p>{formattedDate}</p>
      <p>{appointment.time}</p>
    </div>
  )
}