export type Period = "morning" | "afternoon" | "night"

export function getPeriod(time: string): Period {
  const hour = Number(time.split(":")[0])

  if (hour >= 6 && hour <= 11) {
    return "morning"
  }

  if (hour >= 12 && hour <= 17) {
    return "afternoon"
  }

  return "night"
}